Educational purpose only   
--------------------------------------------          
I'm not responsible for your actions


Created By: EH30



python 2.7
-----------------------------------------------
git clone https://github.com/EH30/dosnet
cd dosnet
pip install -r requirements.txt
python dosnet.py
------------------------------------------------
