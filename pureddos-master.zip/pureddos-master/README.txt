########################################
# Educational purpose only             #
########################################
# I'm not responsible for your actions #
########################################




--------------------------------------------------
git clone https://github.com/EH30/pureddos
cd pureddos
python pureddos.py
--------------------------------------------------